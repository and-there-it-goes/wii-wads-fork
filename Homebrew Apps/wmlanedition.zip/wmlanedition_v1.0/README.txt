+------------------------------------+
|   WAD Manager - LAN Edition v1.0   |
|        developed by RhAiGe         |
+------------------------------------+
|      wmlanedition.blogspot.com     |
+------------------------------------+


[ DISCLAIMER ]:

- THIS APPLICATION COMES WITH NO WARRANTY AT ALL, NEITHER EXPRESS NOR IMPLIED.
  I DO NOT TAKE ANY RESPONSIBILITY FOR ANY DAMAGE IN YOUR WII CONSOLE
  BECAUSE OF A IMPROPER USAGE OF THIS SOFTWARE.
  
- YOU SHOULD USE ONLY WITH GAMES THAT YOU OWN



[ DESCRIPTION ]:

- WAD Manager is an application that allows you to (un)install
  WAD packages.
  
- LAN Edition is an addon that allows you to (un)install WAD
  packages directly from your PC through the local network



[ HOW TO USE ]:

1. Install the windows service on your PC (setup.exe)
2. Check the IP address shown on the cmd screen at the end of the installation (black screen) 
3. Open the shortcut created on your desktop (WAD Manager - LAN Edition)
4. Copy the apps folder to your SD card
5. Run the application with any method to load homebrew (i.e. Homebrew Channel)



[ REPORT ERRORS ]:

1. Go to http://www.assembla.com/spaces/wmlanedition/tickets
2. Open a New Ticket
3. Write a detailed description about the problem
     - what you were doing
     - what happened
     - error code returned
     - add some contact info
     - any other useful info
4. Create the ticket



[ SOURCE ]:

- SVN: http://subversion.assembla.com/svn/wmlanedition



[ NOTES ]:

- You can easily uninstall it through the Control Panel
- If it takes a long time to connect it is because the service is
  not running properly or the IP address is wrong
     - check your IP address on config.ini (in your SD card)
     - restart your PC in order to restart the windows service
- If you have many files on a single directory, it will take more
  time to list all the files



[ THANKS ]:

- waninkoko: Thanks for the WAD Manager!
- pembo: Thanks for the RFD library!

Note: pembo doesn't have anything to do with any WAD related stuff



---------------------------------------------------------------------------------------
