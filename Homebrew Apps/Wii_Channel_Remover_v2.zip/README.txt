+------------------------------------------------+
| Wii Duplicated Channel Remover v2 by Waninkoko |
+------------------------------------------------+

This application removes the duplicated channels installed after upgrading the Wii
with a game from a different region.

Just run the application and it will autodetect the duplicated channels and remove them.


IMPORTANT NOTE: Use the specific version for your Wii!!
DISCLAIMER:     I don't take any responsability if your Wii gets damaged.


Kudos to bushing, marcan, pistu and Vasco_Almeida.
